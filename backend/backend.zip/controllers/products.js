const Product = require("../models/product");
const _ = require("lodash");


exports.newProduct = (req, res) => {
  const { nameTR, nameFR, nameDE, nameSP, nameNL, imageStr,gen } = req.body;

  let newProduct = new Product({
    nameTR,
    nameFR,
    nameDE,
    nameSP,
    nameNL,
    imageStr,
    gen
  });

  newProduct.save((err, success) => {
    if (err) {
      console.log("Activation Error: ", err);
      return res
        .status(400)
        .json({ error: "Product didn t added to database" });
    }
    console.log(nameTR + " urunu Eklendi");
    res.status(200).json({
      message: "Success!",
    });
  });
};

exports.getProduct = (req, res) => {
  Product.find((err, data) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.status(200).send(data);
    }
  });
};


exports.deleteProduct = (req, res) => {
  const id = req.params.id;

  Product.find((err, data) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.status(200).send(data.find((item) => item._id == id).delete());
    }
  });
};
